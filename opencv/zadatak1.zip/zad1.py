# Osnovna manipulacijama slikama pomocu Pillow biblioteke

from PIL import Image

print("hello")

# TODO
