Ovdje pohranite grayscale slike.
