import glob

imgPath = "images" 
files = glob.glob(imgPath + '/**/*.jpg', recursive=True)

# TODO ispisite sve putanje


# TODO svaku sliku pretvorite u grayscale i spremite u output direktorij pod nazivom img_x.jpg pri cemu je x redni broj slike

